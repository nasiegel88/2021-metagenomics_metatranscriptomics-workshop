The contents of this directory were downloaded from Illumina on: August 30, 2011

