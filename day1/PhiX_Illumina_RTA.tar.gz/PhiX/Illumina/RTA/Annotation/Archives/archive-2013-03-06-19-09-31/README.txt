The contents of this directory were downloaded from Illumina on: March 6, 2013

