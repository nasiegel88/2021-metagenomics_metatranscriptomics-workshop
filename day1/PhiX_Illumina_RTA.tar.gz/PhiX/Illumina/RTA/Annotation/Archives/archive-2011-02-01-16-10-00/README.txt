The contents of this directory were downloaded from Illumina on:
February 1, 2011


