The contents of this directory were downloaded from Illumina on: March 9, 2012

