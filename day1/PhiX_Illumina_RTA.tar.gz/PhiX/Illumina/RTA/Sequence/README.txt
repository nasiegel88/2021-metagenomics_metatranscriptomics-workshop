
Feb 2, 2011

There are 5 single-nucleotide differences between the PhiX sequence from NCBI and the PhiX sequence from Illumina. Both sequences have length of 5386 bp. The difference are (in 1-based coordinates):

Position    NCBI    Illumina
----------------------------
587         G       A
833         G       A
2731        A       G
2793        C       T
2811        C       T

The Illumina Phix sequence is used by RTA to report initial error rates. Note that in practice some sites in PhiX are heterozygous.
